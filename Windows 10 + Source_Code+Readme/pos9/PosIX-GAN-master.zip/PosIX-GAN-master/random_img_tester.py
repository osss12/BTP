
import time
from keras.utils import generic_utils
from keras.losses import mean_squared_error as loss_pmse
import numpy.linalg as LA
from PIL import Image
import math
from keras import backend as k
from scipy import misc
from keras.preprocessing import image
from keras.optimizers import Adam
import tensorflow as tf
import numpy as np
# from keras.models import load_weights
import keras
import models
import train
import utils
import os
from keras.utils import plot_model

img_size = 64  # Size of square image
channels = 3  # 1 for grayscale
z = 256  # Generator input


def create_inputs_headpose():
    ts_x , ts_y= load_headpose()
    ts_x = ts_x.astype(np.float32) / 255.
    original_shape = ts_x.shape

    new_shape = (-1, original_shape[0], original_shape[1], original_shape[2])
    reshaped_array = ts_x.reshape(new_shape)
    print(np.shape(reshaped_array))
    print("------------------------")
    
    reshaped_array = np.rollaxis(reshaped_array, 3, 1)
    return (reshaped_array , ts_y)


def load_headpose():
    tsImages = np.load('output_image.npy')
    tslabel = np.load('pmse_label_set1.npy')
    return tsImages,tslabel


tsImages , yt = create_inputs_headpose()

generator = models.b_generator(z, img_size, channels)
print('generator summary')
print (generator.summary())
discriminator = models.b_discriminator(img_size, channels)
print('discriminator summary')
print (discriminator.summary())
gan = models.generator_containing_discriminator(generator, discriminator)

print (gan.summary())

generator.load_weights('gen_epoch600.h5') # load weights of the generator model
discriminator.load_weights('disc_epoch600.h5') # load weights of the discriminator model
gan = models.generator_containing_discriminator(generator, discriminator)
tsImages , yt = create_inputs_headpose()
print("reached here")
gen = generator.predict(tsImages)
print(gen)

e = 1
nb_epoch = 1
for i in range(9):
    
    gen0 = np.rollaxis(gen[i], 3, 1)
    gen0 = np.rollaxis(gen0, 3, 1)
    print('gen  b', np.shape(gen))
    print(np.shape(gen[i]));
    print(np.shape(gen0))
    img0 = gen0[0, :, :, :]
    img0 = img0 * 255
    #img1 = img1 * 255
    #img2 = img2 * 255
    #img3 = img3 * 255
    #img4 = img4 * 255
    #img5 = img5 * 255
    #img6 = img6 * 255
    #img7 = img7 * 255
    #img8 = img8 * 255
    #img9 = img9 * 255
    Image.fromarray(img0.astype(np.uint8)).save("random/" +
                                                str(e + 1) + "_" + str(nb_epoch) + str(i) + "0.png")
